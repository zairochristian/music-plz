<script type="text/javascript">

// var btn_play=document.querySelector(".btnp_play");

//     btn_play.addEventListener('click', function()
//     console.log('ecouter le clicksur le btn_play');
// });

</script>
